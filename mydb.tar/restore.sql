--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "tap-on-it";
--
-- Name: tap-on-it; Type: DATABASE; Schema: -; Owner: seanbeach
--

CREATE DATABASE "tap-on-it" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE "tap-on-it" OWNER TO seanbeach;

\connect -reuse-previous=on "dbname='tap-on-it'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: paintings; Type: TABLE; Schema: public; Owner: seanbeach
--

CREATE TABLE public.paintings (
    id integer,
    name character varying(50) NOT NULL,
    artist character varying(50) NOT NULL,
    url character varying(50) NOT NULL,
    likes integer,
    painted_in character varying(50) NOT NULL
);


ALTER TABLE public.paintings OWNER TO seanbeach;

--
-- Data for Name: paintings; Type: TABLE DATA; Schema: public; Owner: seanbeach
--

COPY public.paintings (id, name, artist, url, likes, painted_in) FROM stdin;
\.
COPY public.paintings (id, name, artist, url, likes, painted_in) FROM '$$PATH$$/3185.dat';

--
-- Name: paintings paintings_name_key; Type: CONSTRAINT; Schema: public; Owner: seanbeach
--

ALTER TABLE ONLY public.paintings
    ADD CONSTRAINT paintings_name_key UNIQUE (name);


--
-- Name: paintings paintings_url_key; Type: CONSTRAINT; Schema: public; Owner: seanbeach
--

ALTER TABLE ONLY public.paintings
    ADD CONSTRAINT paintings_url_key UNIQUE (url);


--
-- PostgreSQL database dump complete
--

